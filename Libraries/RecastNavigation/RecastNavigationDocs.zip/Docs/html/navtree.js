var NAVTREE =
[
  [ "Recast Navigation", "index.html", [
    [ "Recast Navigation", "index.html", null ],
    [ "Related Pages", "pages.html", [
      [ "License", "License.html", null ]
    ] ],
    [ "Modules", "modules.html", [
      [ "Detour", "group__detour.html", null ],
      [ "Crowd", "group__crowd.html", null ],
      [ "Recast", "group__recast.html", null ]
    ] ],
    [ "Class List", "annotated.html", [
      [ "BuildContext", "structBuildContext.html", null ],
      [ "BVItem", "structBVItem.html", null ],
      [ "dtBVNode", "structdtBVNode.html", null ],
      [ "dtCompressedTile", "structdtCompressedTile.html", null ],
      [ "dtCrowd", "classdtCrowd.html", null ],
      [ "dtCrowdAgent", "structdtCrowdAgent.html", null ],
      [ "dtCrowdAgentAnimation", "structdtCrowdAgentAnimation.html", null ],
      [ "dtCrowdAgentDebugInfo", "structdtCrowdAgentDebugInfo.html", null ],
      [ "dtCrowdAgentParams", "structdtCrowdAgentParams.html", null ],
      [ "dtCrowdNeighbour", "structdtCrowdNeighbour.html", null ],
      [ "dtFixedArray< T >", "classdtFixedArray.html", null ],
      [ "dtLayerMonotoneRegion", "structdtLayerMonotoneRegion.html", null ],
      [ "dtLayerSweepSpan", "structdtLayerSweepSpan.html", null ],
      [ "dtLink", "structdtLink.html", null ],
      [ "dtLocalBoundary", "classdtLocalBoundary.html", null ],
      [ "dtMeshHeader", "structdtMeshHeader.html", null ],
      [ "dtMeshTile", "structdtMeshTile.html", null ],
      [ "dtNavMesh", "classdtNavMesh.html", null ],
      [ "dtNavMeshCreateParams", "structdtNavMeshCreateParams.html", null ],
      [ "dtNavMeshParams", "structdtNavMeshParams.html", null ],
      [ "dtNavMeshQuery", "classdtNavMeshQuery.html", null ],
      [ "dtNode", "structdtNode.html", null ],
      [ "dtNodePool", "classdtNodePool.html", null ],
      [ "dtNodeQueue", "classdtNodeQueue.html", null ],
      [ "dtObstacleAvoidanceDebugData", "classdtObstacleAvoidanceDebugData.html", null ],
      [ "dtObstacleAvoidanceParams", "structdtObstacleAvoidanceParams.html", null ],
      [ "dtObstacleAvoidanceQuery", "classdtObstacleAvoidanceQuery.html", null ],
      [ "dtObstacleCircle", "structdtObstacleCircle.html", null ],
      [ "dtObstacleSegment", "structdtObstacleSegment.html", null ],
      [ "dtOffMeshConnection", "structdtOffMeshConnection.html", null ],
      [ "dtPathCorridor", "classdtPathCorridor.html", null ],
      [ "dtPathQueue", "classdtPathQueue.html", null ],
      [ "dtPoly", "structdtPoly.html", null ],
      [ "dtPolyDetail", "structdtPolyDetail.html", null ],
      [ "dtPolyState", "structdtPolyState.html", null ],
      [ "dtProximityGrid", "classdtProximityGrid.html", null ],
      [ "dtQueryFilter", "classdtQueryFilter.html", null ],
      [ "dtSegInterval", "structdtSegInterval.html", null ],
      [ "dtTempContour", "structdtTempContour.html", null ],
      [ "dtTileCache", "classdtTileCache.html", null ],
      [ "dtTileCacheAlloc", "structdtTileCacheAlloc.html", null ],
      [ "dtTileCacheCompressor", "structdtTileCacheCompressor.html", null ],
      [ "dtTileCacheContour", "structdtTileCacheContour.html", null ],
      [ "dtTileCacheContourSet", "structdtTileCacheContourSet.html", null ],
      [ "dtTileCacheLayer", "structdtTileCacheLayer.html", null ],
      [ "dtTileCacheLayerHeader", "structdtTileCacheLayerHeader.html", null ],
      [ "dtTileCacheObstacle", "structdtTileCacheObstacle.html", null ],
      [ "dtTileCacheParams", "structdtTileCacheParams.html", null ],
      [ "dtTileCachePolyMesh", "structdtTileCachePolyMesh.html", null ],
      [ "dtTileState", "structdtTileState.html", null ],
      [ "rcCompactCell", "structrcCompactCell.html", null ],
      [ "rcCompactHeightfield", "structrcCompactHeightfield.html", null ],
      [ "rcCompactSpan", "structrcCompactSpan.html", null ],
      [ "rcConfig", "structrcConfig.html", null ],
      [ "rcContext", "classrcContext.html", null ],
      [ "rcContour", "structrcContour.html", null ],
      [ "rcContourSet", "structrcContourSet.html", null ],
      [ "rcEdge", "structrcEdge.html", null ],
      [ "rcHeightfield", "structrcHeightfield.html", null ],
      [ "rcHeightfieldLayer", "structrcHeightfieldLayer.html", null ],
      [ "rcHeightfieldLayerSet", "structrcHeightfieldLayerSet.html", null ],
      [ "rcHeightPatch", "structrcHeightPatch.html", null ],
      [ "rcIntArray", "classrcIntArray.html", null ],
      [ "rcLayerRegion", "structrcLayerRegion.html", null ],
      [ "rcLayerSweepSpan", "structrcLayerSweepSpan.html", null ],
      [ "rcPolyMesh", "structrcPolyMesh.html", null ],
      [ "rcPolyMeshDetail", "structrcPolyMeshDetail.html", null ],
      [ "rcRegion", "structrcRegion.html", null ],
      [ "rcScopedDelete< T >", "classrcScopedDelete.html", null ],
      [ "rcSpan", "structrcSpan.html", null ],
      [ "rcSpanPool", "structrcSpanPool.html", null ],
      [ "rcSweepSpan", "structrcSweepSpan.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Members", "functions.html", null ],
    [ "File List", "files.html", [
      [ "DetourAlloc.cpp", "DetourAlloc_8cpp.html", null ],
      [ "DetourAlloc.h", "DetourAlloc_8h.html", null ],
      [ "DetourAssert.h", "DetourAssert_8h.html", null ],
      [ "DetourCommon.cpp", "DetourCommon_8cpp.html", null ],
      [ "DetourCommon.h", "DetourCommon_8h.html", null ],
      [ "DetourCrowd.cpp", "DetourCrowd_8cpp.html", null ],
      [ "DetourCrowd.h", "DetourCrowd_8h.html", null ],
      [ "DetourLocalBoundary.cpp", "DetourLocalBoundary_8cpp.html", null ],
      [ "DetourLocalBoundary.h", "DetourLocalBoundary_8h.html", null ],
      [ "DetourNavMesh.cpp", "DetourNavMesh_8cpp.html", null ],
      [ "DetourNavMesh.h", "DetourNavMesh_8h.html", null ],
      [ "DetourNavMeshBuilder.cpp", "DetourNavMeshBuilder_8cpp.html", null ],
      [ "DetourNavMeshBuilder.h", "DetourNavMeshBuilder_8h.html", null ],
      [ "DetourNavMeshQuery.cpp", "DetourNavMeshQuery_8cpp.html", null ],
      [ "DetourNavMeshQuery.h", "DetourNavMeshQuery_8h.html", null ],
      [ "DetourNode.cpp", "DetourNode_8cpp.html", null ],
      [ "DetourNode.h", "DetourNode_8h.html", null ],
      [ "DetourObstacleAvoidance.cpp", "DetourObstacleAvoidance_8cpp.html", null ],
      [ "DetourObstacleAvoidance.h", "DetourObstacleAvoidance_8h.html", null ],
      [ "DetourPathCorridor.cpp", "DetourPathCorridor_8cpp.html", null ],
      [ "DetourPathCorridor.h", "DetourPathCorridor_8h.html", null ],
      [ "DetourPathQueue.cpp", "DetourPathQueue_8cpp.html", null ],
      [ "DetourPathQueue.h", "DetourPathQueue_8h.html", null ],
      [ "DetourProximityGrid.cpp", "DetourProximityGrid_8cpp.html", null ],
      [ "DetourProximityGrid.h", "DetourProximityGrid_8h.html", null ],
      [ "DetourStatus.h", "DetourStatus_8h.html", null ],
      [ "DetourTileCache.cpp", "DetourTileCache_8cpp.html", null ],
      [ "DetourTileCache.h", "DetourTileCache_8h.html", null ],
      [ "DetourTileCacheBuilder.cpp", "DetourTileCacheBuilder_8cpp.html", null ],
      [ "DetourTileCacheBuilder.h", "DetourTileCacheBuilder_8h.html", null ],
      [ "Recast.cpp", "Recast_8cpp.html", null ],
      [ "Recast.h", "Recast_8h.html", null ],
      [ "RecastAlloc.cpp", "RecastAlloc_8cpp.html", null ],
      [ "RecastAlloc.h", "RecastAlloc_8h.html", null ],
      [ "RecastArea.cpp", "RecastArea_8cpp.html", null ],
      [ "RecastAssert.h", "RecastAssert_8h.html", null ],
      [ "RecastContour.cpp", "RecastContour_8cpp.html", null ],
      [ "RecastFilter.cpp", "RecastFilter_8cpp.html", null ],
      [ "RecastLayers.cpp", "RecastLayers_8cpp.html", null ],
      [ "RecastMesh.cpp", "RecastMesh_8cpp.html", null ],
      [ "RecastMeshDetail.cpp", "RecastMeshDetail_8cpp.html", null ],
      [ "RecastRasterization.cpp", "RecastRasterization_8cpp.html", null ],
      [ "RecastRegion.cpp", "RecastRegion_8cpp.html", null ]
    ] ],
    [ "File Members", "globals.html", null ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

